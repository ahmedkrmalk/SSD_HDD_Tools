package com.example.drivecheck

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager

class ScsiResult(val ok: Boolean, val data: ByteArray, val status: Int)

/**
 * USB Mass Storage "Bulk-Only Transport" بدون روت، عبر USB Host API.
 * يرسل أوامر SCSI خام للهارد (INQUIRY / READ CAPACITY / READ / ATA pass-through).
 */
class UsbBot private constructor(
    private val conn: UsbDeviceConnection,
    private val itf: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint
) {
    private var tag = 1

    fun close() {
        try { conn.releaseInterface(itf) } catch (_: Exception) {}
        conn.close()
    }

    fun exec(cdb: ByteArray, dataLen: Int = 0, timeout: Int = 10000): ScsiResult {
        val cbw = ByteArray(31)
        putLE(cbw, 0, 0x43425355)          // "USBC"
        val myTag = tag++
        putLE(cbw, 4, myTag)
        putLE(cbw, 8, dataLen)
        cbw[12] = if (dataLen > 0) 0x80.toByte() else 0
        cbw[13] = 0
        cbw[14] = cdb.size.toByte()
        System.arraycopy(cdb, 0, cbw, 15, cdb.size)

        if (conn.bulkTransfer(outEp, cbw, cbw.size, timeout) != cbw.size) return ScsiResult(false, ByteArray(0), -1)

        val data = ByteArray(dataLen)
        var got = 0
        while (got < dataLen) {
            val n = conn.bulkTransfer(inEp, data, got, dataLen - got, timeout)
            if (n < 0) { clearHalt(inEp); break }
            got += n
            if (n == 0 || n % inEp.maxPacketSize != 0) break
        }

        var csw = ByteArray(13)
        var r = conn.bulkTransfer(inEp, csw, 13, timeout)
        if (r != 13) {
            clearHalt(inEp)
            r = conn.bulkTransfer(inEp, csw, 13, timeout)
        }
        if (r != 13 || getLE(csw, 0) != 0x53425355 || getLE(csw, 4) != myTag) {
            return ScsiResult(false, data.copyOf(got), -2)
        }
        val status = csw[12].toInt() and 0xFF
        return ScsiResult(status == 0, data.copyOf(got), status)
    }

    private fun clearHalt(ep: UsbEndpoint) {
        conn.controlTransfer(0x02, 0x01, 0, ep.address, null, 0, 1000)
    }

    // ---------- أوامر SCSI ----------

    fun inquiry(): ScsiResult =
        exec(byteArrayOf(0x12, 0, 0, 0, 36, 0), 36)

    /** يرجع (آخر LBA, حجم البلوك) أو null */
    fun readCapacity(): Pair<Long, Int>? {
        val cdb = ByteArray(16)
        cdb[0] = 0x9E.toByte(); cdb[1] = 0x10
        cdb[13] = 32
        val r = exec(cdb, 32)
        if (!r.ok || r.data.size < 12) return null
        var last = 0L
        for (i in 0 until 8) last = (last shl 8) or (r.data[i].toLong() and 0xFF)
        var bs = 0
        for (i in 8 until 12) bs = (bs shl 8) or (r.data[i].toInt() and 0xFF)
        return Pair(last, bs)
    }

    fun read16(lba: Long, blocks: Int, blockSize: Int): ScsiResult {
        val cdb = ByteArray(16)
        cdb[0] = 0x88.toByte()
        for (i in 0 until 8) cdb[2 + i] = (lba shr (8 * (7 - i))).toByte()
        for (i in 0 until 4) cdb[10 + i] = (blocks shr (8 * (3 - i))).toByte()
        return exec(cdb, blocks * blockSize)
    }

    companion object {
        fun hasBot(d: UsbDevice): Boolean = findInterface(d) != null

        private fun findInterface(d: UsbDevice): UsbInterface? {
            for (i in 0 until d.interfaceCount) {
                val itf = d.getInterface(i)
                // Mass storage / SCSI / Bulk-Only (0x50). أغلب العلب تدعم BOT بجانب UAS.
                if (itf.interfaceClass == 8 && itf.interfaceSubclass == 6 && itf.interfaceProtocol == 0x50) return itf
            }
            return null
        }

        fun open(d: UsbDevice, mgr: UsbManager): UsbBot? {
            val itf = findInterface(d) ?: return null
            val c = mgr.openDevice(d) ?: return null
            if (!c.claimInterface(itf, true)) { c.close(); return null }
            c.setInterface(itf)
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
                }
            }
            if (inEp == null || outEp == null) { c.close(); return null }
            return UsbBot(c, itf, inEp, outEp)
        }

        private fun putLE(b: ByteArray, o: Int, v: Int) {
            for (i in 0 until 4) b[o + i] = (v shr (8 * i)).toByte()
        }

        private fun getLE(b: ByteArray, o: Int): Int {
            var v = 0
            for (i in 0 until 4) v = v or ((b[o + i].toInt() and 0xFF) shl (8 * i))
            return v
        }
    }
}
