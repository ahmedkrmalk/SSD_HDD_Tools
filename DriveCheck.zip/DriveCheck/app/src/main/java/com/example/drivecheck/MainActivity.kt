package com.example.drivecheck

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.FileOutputStream
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity() {

    private lateinit var out: TextView
    private lateinit var mgr: UsbManager
    private val ACTION_PERM = "com.example.drivecheck.USB_PERMISSION"
    private val REQ_TREE = 42

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != ACTION_PERM) return
            val dev: UsbDevice? =
                if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                else @Suppress("DEPRECATION") i.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            if (dev != null && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) runCheck(dev)
            else log("تم رفض إذن الوصول لجهاز USB.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mgr = getSystemService(USB_SERVICE) as UsbManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }
        val b1 = Button(this).apply {
            text = "فحص الهارد (SMART + سرعة القراءة)"
            setOnClickListener { start() }
        }
        val b2 = Button(this).apply {
            text = "اختبار سرعة الكتابة (اختر مجلد على الهارد)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
            }
        }
        out = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 13f
            textDirection = View.TEXT_DIRECTION_ANY_RTL
            setTextIsSelectable(true)
            text = "وصّل الهارد بكيبل Type-C ثم اضغط فحص.\n"
        }
        root.addView(b1)
        root.addView(b2)
        root.addView(ScrollView(this).apply { addView(out) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val f = IntentFilter(ACTION_PERM)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    private fun log(s: String) = runOnUiThread { out.append(s + "\n") }

    // ---------------- الفحص ----------------

    private fun start() {
        out.text = ""
        val dev = mgr.deviceList.values.firstOrNull { UsbBot.hasBot(it) }
        if (dev == null) {
            log("لم أجد هارد USB بنظام Bulk-Only.\nتأكد من التوصيل، أو أن العلبة ليست UAS فقط.")
            return
        }
        if (mgr.hasPermission(dev)) {
            runCheck(dev)
        } else {
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_PERM).setPackage(packageName), flags)
            mgr.requestPermission(dev, pi)
        }
    }

    private fun runCheck(dev: UsbDevice) {
        Thread {
            val bot = UsbBot.open(dev, mgr)
            if (bot == null) { log("تعذّر فتح الجهاز."); return@Thread }
            try {
                log("⚠ سيُفصل الهارد مؤقتاً عن نظام الأندرويد أثناء الفحص ويرجع بعده.\n")

                val inq = bot.inquiry()
                if (inq.ok && inq.data.size >= 32) {
                    val vendor = String(inq.data, 8, 8).trim()
                    val product = String(inq.data, 16, 16).trim()
                    log("الجهاز: $vendor $product")
                }
                val cap = bot.readCapacity()
                if (cap == null) { log("فشلت قراءة السعة."); return@Thread }
                val (lastLba, bs) = cap
                val total = (lastLba + 1) * bs
                log(String.format(Locale.US, "السعة: %.1f GB  (حجم البلوك %d)\n", total / 1e9, bs))

                // ---- SMART / الصحة ----
                log("── الصحة (SMART) ──")
                val rep = try { Smart.read(bot) } catch (e: Exception) { null }
                if (rep == null) {
                    log("غير متاح: علبة الهارد لا تمرّر أوامر SMART (شائع في بعض علب WD/Seagate/UAS).")
                    log("تقدر تكمل اختبار الأداء فقط.\n")
                } else {
                    log("الموديل: ${rep.model}   السيريال: ${rep.serial}")
                    log("النوع: ${if (rep.isSsd) "SSD" else "HDD"}")
                    log("الصحة: ${rep.healthPercent}%  — ${rep.verdict}")
                    rep.tempC?.let { log("الحرارة: $it°C") }
                    rep.reasons.forEach { log("• $it") }
                    log("")
                    log(String.format("%-4s %-24s %4s %4s %4s %s", "ID", "Name", "Val", "Wst", "Thr", "Raw"))
                    rep.attrs.forEach {
                        log(String.format("%-4d %-24s %4d %4d %4d %d%s", it.id, Smart.name(it.id).take(24),
                            it.value, it.worst, it.thresh, it.raw, if (it.failing) "  !!" else ""))
                    }
                    log("")
                }

                // ---- الأداء ----
                log("── الأداء (قراءة خام) ──")
                seqRead(bot, lastLba, bs)
                randRead(bot, lastLba, bs)
                log("\nانتهى الفحص.")
            } catch (e: Exception) {
                log("خطأ: ${e.message}")
            } finally {
                bot.close()
            }
        }.start()
    }

    private fun seqRead(bot: UsbBot, lastLba: Long, bs: Int) {
        val chunk = 1 shl 20
        val blocks = chunk / bs
        var lba = 0L
        var bytes = 0L
        val t0 = System.nanoTime()
        var winStart = t0
        var winBytes = 0L
        var minWin = Double.MAX_VALUE
        while (System.nanoTime() - t0 < 8_000_000_000L && lba + blocks <= lastLba && bytes < (1L shl 30)) {
            val r = bot.read16(lba, blocks, bs)
            if (!r.ok || r.data.size != chunk) { log("فشلت القراءة عند LBA=$lba"); break }
            lba += blocks; bytes += chunk; winBytes += chunk
            val now = System.nanoTime()
            if (now - winStart >= 1_000_000_000L) {
                minWin = minOf(minWin, winBytes / ((now - winStart) / 1e9) / 1e6)
                winStart = now; winBytes = 0
            }
        }
        val sec = (System.nanoTime() - t0) / 1e9
        if (bytes > 0) {
            log(String.format(Locale.US, "قراءة متسلسلة: %.1f MB/s", bytes / sec / 1e6))
            if (minWin != Double.MAX_VALUE) log(String.format(Locale.US, "أبطأ ثانية: %.1f MB/s", minWin))
        }
    }

    private fun randRead(bot: UsbBot, lastLba: Long, bs: Int) {
        val n = 300
        val blocks = maxOf(1, 4096 / bs)
        val lat = ArrayList<Double>()
        val t0 = System.nanoTime()
        for (i in 0 until n) {
            val lba = Random.nextLong(0, lastLba - blocks)
            val s = System.nanoTime()
            val r = bot.read16(lba, blocks, bs)
            if (!r.ok) { log("فشلت قراءة عشوائية"); break }
            lat.add((System.nanoTime() - s) / 1e6)
        }
        if (lat.isEmpty()) return
        lat.sort()
        val total = (System.nanoTime() - t0) / 1e9
        log(String.format(Locale.US, "قراءة عشوائية 4K: %.0f IOPS | متوسط %.2f ms | p95 %.2f ms",
            lat.size / total, lat.average(), lat[(lat.size * 0.95).toInt().coerceAtMost(lat.size - 1)]))
    }

    // ---------------- اختبار الكتابة عبر SAF ----------------

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TREE && resultCode == RESULT_OK && data?.data != null) {
            val tree = data.data!!
            out.text = ""
            Thread { writeTest(tree) }.start()
        }
    }

    private fun writeTest(tree: Uri) {
        try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val file = DocumentsContract.createDocument(contentResolver, parent, "application/octet-stream", "drivecheck.tmp")
            if (file == null) { log("تعذّر إنشاء ملف الاختبار في هذا المجلد."); return }
            val chunk = ByteArray(4 shl 20).also { Random.nextBytes(it) }
            val total = 256 shl 20
            log("أكتب ${total shr 20} MB على المجلد المختار...")
            contentResolver.openFileDescriptor(file, "w")!!.use { pfd ->
                FileOutputStream(pfd.fileDescriptor).use { fos ->
                    val t0 = System.nanoTime()
                    var written = 0
                    while (written < total) { fos.write(chunk); written += chunk.size }
                    fos.fd.sync()
                    val sec = (System.nanoTime() - t0) / 1e9
                    log(String.format(Locale.US, "كتابة متسلسلة: %.1f MB/s", total / sec / 1e6))
                }
            }
            DocumentsContract.deleteDocument(contentResolver, file)
            log("تم حذف ملف الاختبار.")
        } catch (e: Exception) {
            log("خطأ في اختبار الكتابة: ${e.message}")
        }
    }
}
