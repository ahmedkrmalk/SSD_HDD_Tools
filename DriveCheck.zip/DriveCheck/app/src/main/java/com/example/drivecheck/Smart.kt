package com.example.drivecheck

class SmartAttr(val id: Int, val value: Int, val worst: Int, val raw: Long, var thresh: Int = 0) {
    val failing get() = thresh > 0 && value <= thresh
}

class SmartReport(
    val model: String,
    val serial: String,
    val isSsd: Boolean,
    val attrs: List<SmartAttr>,
    val healthPercent: Int,
    val verdict: String,
    val reasons: List<String>,
    val tempC: Int?
)

/** قراءة SMART عبر ATA PASS-THROUGH (SAT). تعمل فقط لو شريحة العلبة تدعمه. */
object Smart {

    private fun ata(cmd: Int, feature: Int, count: Int, mid: Int, high: Int, dataIn: Boolean): ByteArray {
        val c = ByteArray(16)
        c[0] = 0x85.toByte()
        c[1] = ((if (dataIn) 4 else 3) shl 1).toByte()      // PIO data-in / non-data
        c[2] = if (dataIn) 0x0E else 0x00                    // t_dir=in, byte_block=1, t_length=sector count
        c[4] = feature.toByte()
        c[6] = count.toByte()
        c[10] = mid.toByte()
        c[12] = high.toByte()
        c[14] = cmd.toByte()
        return c
    }

    fun read(bot: UsbBot): SmartReport? {
        val id = bot.exec(ata(0xEC, 0, 1, 0, 0, true), 512)
        if (!id.ok || id.data.size < 512) return null

        bot.exec(ata(0xB0, 0xD8, 0, 0x4F, 0xC2, false), 0)           // SMART ENABLE
        val sm = bot.exec(ata(0xB0, 0xD0, 1, 0x4F, 0xC2, true), 512)  // SMART READ DATA
        if (!sm.ok || sm.data.size < 512) return null
        val th = bot.exec(ata(0xB0, 0xD1, 1, 0x4F, 0xC2, true), 512)  // SMART READ THRESHOLDS

        val attrs = ArrayList<SmartAttr>()
        for (i in 0 until 30) {
            val o = 2 + i * 12
            val aid = sm.data[o].toInt() and 0xFF
            if (aid == 0) continue
            var raw = 0L
            for (k in 5 downTo 0) raw = (raw shl 8) or (sm.data[o + 5 + k].toLong() and 0xFF)
            attrs.add(SmartAttr(aid, sm.data[o + 3].toInt() and 0xFF, sm.data[o + 4].toInt() and 0xFF, raw))
        }
        if (th.ok && th.data.size >= 512) {
            for (i in 0 until 30) {
                val o = 2 + i * 12
                val tid = th.data[o].toInt() and 0xFF
                if (tid == 0) continue
                attrs.find { it.id == tid }?.thresh = th.data[o + 1].toInt() and 0xFF
            }
        }

        val model = ataString(id.data, 27, 20)
        val serial = ataString(id.data, 10, 10)
        val rotation = (id.data[434].toInt() and 0xFF) or ((id.data[435].toInt() and 0xFF) shl 8) // كلمة 217
        val isSsd = rotation == 1

        val reasons = ArrayList<String>()
        var score = 100
        fun raw(id: Int) = attrs.find { it.id == id }?.raw ?: 0L

        attrs.filter { it.failing }.forEach {
            score = minOf(score, 10)
            reasons.add("السمة ${it.id} (${name(it.id)}) وصلت لحد الفشل المصنعي")
        }
        if (raw(5) > 0) { score -= if (raw(5) > 100) 40 else 15; reasons.add("قطاعات معاد تخصيصها (Reallocated): ${raw(5)}") }
        if (raw(197) > 0) { score -= 20; reasons.add("قطاعات معلّقة (Pending): ${raw(197)}") }
        if (raw(198) > 0) { score -= 20; reasons.add("قطاعات غير قابلة للتصحيح (Uncorrectable): ${raw(198)}") }
        if (raw(187) > 0) { score -= 15; reasons.add("أخطاء غير قابلة للتصحيح مُبلَّغ عنها: ${raw(187)}") }
        if (raw(199) > 0) { score -= 5; reasons.add("أخطاء CRC على الكيبل/المنفذ: ${raw(199)} (جرّب كيبل آخر)") }

        // عمر الـ SSD (قيم مُطبَّعة 100 → 0)
        for (lifeId in intArrayOf(177, 231, 233)) {
            attrs.find { it.id == lifeId }?.let { if (isSsd && it.value in 1..100) score = minOf(score, it.value) }
        }

        val temp = attrs.find { it.id == 194 || it.id == 190 }?.let { (it.raw and 0xFF).toInt() }
        if (temp != null && temp > 55) { score -= 10; reasons.add("الحرارة مرتفعة: $temp°C") }

        score = score.coerceIn(0, 100)
        val verdict = when {
            score >= 90 -> "ممتاز"
            score >= 70 -> "جيد"
            score >= 40 -> "تحذير — انسخ بياناتك احتياطياً"
            else -> "سيئ — الهارد معرّض للتلف"
        }
        return SmartReport(model, serial, isSsd, attrs, score, verdict, reasons, temp)
    }

    private fun ataString(d: ByteArray, wordStart: Int, words: Int): String {
        val sb = StringBuilder()
        for (w in wordStart until wordStart + words) {
            sb.append((d[w * 2 + 1].toInt() and 0xFF).toChar())
            sb.append((d[w * 2].toInt() and 0xFF).toChar())
        }
        return sb.toString().trim()
    }

    fun name(id: Int) = when (id) {
        1 -> "Read Error Rate"; 3 -> "Spin-Up Time"; 4 -> "Start/Stop Count"
        5 -> "Reallocated Sectors"; 7 -> "Seek Error Rate"; 9 -> "Power-On Hours"
        10 -> "Spin Retry Count"; 12 -> "Power Cycle Count"; 177 -> "Wear Leveling Count"
        179 -> "Used Reserved Blocks"; 181 -> "Program Fail Count"; 182 -> "Erase Fail Count"
        187 -> "Reported Uncorrectable"; 188 -> "Command Timeout"; 190 -> "Airflow Temp"
        191 -> "G-Sense Error"; 192 -> "Power-Off Retract"; 193 -> "Load Cycle Count"
        194 -> "Temperature"; 196 -> "Reallocation Events"; 197 -> "Current Pending Sectors"
        198 -> "Offline Uncorrectable"; 199 -> "UDMA CRC Errors"; 231 -> "SSD Life Left"
        233 -> "Media Wearout"; 241 -> "Total LBAs Written"; 242 -> "Total LBAs Read"
        else -> "Attr $id"
    }
}
